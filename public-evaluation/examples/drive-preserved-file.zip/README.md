# Trace a preserved Drive file

Which folder supplied the preserved file, which action requested it, and do its size and hash match the file record?

This separately prepared example uses synthetic content and a simulated device. The PNG illustrates the fixture screen and the XML represents its visible fields. Both were prepared for this exercise.

## Trace the record

Extract this example ZIP. From the folder containing `session.json`, run the result validator from your AURA checkout. Replace `/path/to/AURA` with the checkout location.

```sh
python3 /path/to/AURA/tools/validate_aura_results.py session.json --trace artifact-000003
```

The validator checks the native session and run package and prints the linked records as JSON. To inspect the records by hand, extract `session-example-drive-001-google_drive-materialize-controlled-online.zip` into a separate folder.

1. In `acquisition.json`, find `artifact-000003` under `artifacts`. The record identifies `artifacts/sample-note.txt`, its byte size and SHA-256, and its owning attempt.
2. Follow `attempt_id` to `attempt-000001`, then follow `acquisition_item_id` to `item-000001`. Read the displayed filename and source folder under `source`.
3. In `events.jsonl`, filter by the same attempt. The sequence opens the file menu, selects Download, and preserves the file. Open the PNG and UI XML referenced by `observation-000001` to inspect the displayed folder, filename, and menu.
4. Hash the unpacked text file and compare the result and its byte size with the artifact record.

## Expected result

The source was `sample-note.txt` in `Review space / Blue folder`. The run used Materialize in controlled-online conditions. `action-000004` selected Download and `action-000005` preserved the file. The attempt is `completed / acquired`. The 62-byte example file has SHA-256 `7213bf860994dda7b10bda7cfd79ad1245adfdcf65f030cb885286b5d7b24324`.
