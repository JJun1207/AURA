# Review a partial Telegram acquisition

Which chat and message supplied the attachment record? What was preserved, and what evidence explains the partial outcome?

This separately prepared example uses synthetic content and a simulated device. The PNG illustrates the fixture screen and the XML represents its visible fields. Both were prepared for this exercise.

## Trace the record

Extract this example ZIP. From the folder containing `session.json`, run the result validator from your AURA checkout. Replace `/path/to/AURA` with the checkout location.

```sh
python3 /path/to/AURA/tools/validate_aura_results.py session.json --trace artifact-000003
```

The validator checks the native session and run package and prints the linked records as JSON. To inspect the records by hand, extract `session-example-telegram-001-telegram-materialize-device-only.zip` into a separate folder.

1. In `acquisition.json`, start at `artifact-000003`, the record for `artifacts/record.json`. Follow its `attempt_id` to `attempt-000001` and its item reference to `item-000001`. Read the chat, message and attachment references.
2. Filter `events.jsonl` by the attempt. The menu was opened and dismissed. Follow `observation-000001` to the menu PNG and UI XML. Check which actions were offered.
3. Read `artifacts/record.json` for the displayed attachment information and `artifacts/audit.json` for the save-action and file-retention checks. In `acquisition.json`, compare the attempt statuses with the reason in `outcome-000001`.
4. To start at the outcome instead, run the same validator command with `--trace outcome-000001`.

## Expected result

The attachment was video `V01` in message `M02` of `Demo room`. Materialize ran in device-only conditions. The menu offered Reply, Forward, Pin and Delete. The display record, menu PNG and XML, and audit were preserved. The audit records an unavailable save action and no retained video. The attempt is `completed / partial`, with reason `save_action_unavailable`.
